const svgMarkup = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10.95 6.51" width="11" heigth="6"> <g xmlns="http://www.w3.org/2000/svg" transform="matrix(0 1 -1 0 11.5 -0.97)"> <path d="M1.18031 10.2493C0.895195 10.5344 0.895196 10.9967 1.18031 11.2818C1.46543 11.5669 1.9277 11.5669 2.21281 11.2818L7.47156 6.02305L2.21281 0.764297C1.9277 0.47918 1.46543 0.47918 1.18031 0.764297C0.895196 1.04941 0.895196 1.51168 1.18031 1.7968L5.40656 6.02305L1.18031 10.2493Z" fill="white"></path> </g> </svg>`;

const firstSlider = tns({
    container: '.first-slider',
    items: 1,
    gutter: 10,
    slideBy: 'page',
    autoplay: true,
    nav: false,
    autoplayButtonOutput: false,
    controlsText: [svgMarkup, svgMarkup],
});

const secondSlider = tns({
    container: '.second-slider',
    items: 1,
    gutter: 10,
    slideBy: 'page',
    autoplay: true,
    nav: false,
    autoplayButtonOutput: false,
    controlsText: [svgMarkup, svgMarkup]
});