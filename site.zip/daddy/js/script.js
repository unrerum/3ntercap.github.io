function sliders() {
    let w = window.innerWidth;

    let slidesConfig = {
        first: 3,
        second: 8,
        third: 7
    };

    if (w < 1920 && w > 1640) {
        slidesConfig.second = 7;
    } else if (w < 1640 && w > 1500) {
        slidesConfig.second = 6;
    } else if (w < 1500 && w > 950) {
        slidesConfig.second = 5;
        slidesConfig.third = 5;
        slidesConfig.first = 2;
    } else if (w < 950 && w > 768) {
        slidesConfig.second = 4;
        slidesConfig.third = 4;
        slidesConfig.first = 2;
    } else if (w <= 768 && w > 660) {
        slidesConfig.second = 3;
        slidesConfig.third = 4;
        slidesConfig.first = 2;
    } else if (w <= 660 && w > 630) {
        slidesConfig.second = 3;
        slidesConfig.third = 4;
        slidesConfig.first = 1;
    } else if (w <= 630 && w > 300) {
        slidesConfig.second = 2;
        slidesConfig.third = 2;
        slidesConfig.first = 1;
    } else {
        slidesConfig.second = 8;
    }

    const swiperFirst = new Swiper(".mainSwiper", {
        speed: 4000,
        slidesPerView: slidesConfig.first,
        spaceBetween: 20,
        slidesPerGroup: 1,
        autoplay: false,
        delay: 5000,
    });

    const swiperSecond = new Swiper(".gameSwiper", {
        slidesPerView: slidesConfig.second,
        grid: {
            rows: 2,
        },
        spaceBetween: 15,
        autoplay: true,
        slidesPerGroup: 3,
    });

    const swiperThird = new Swiper(".providerSwiper", {
        slidesPerView: slidesConfig.third,
        grid: {
            rows: 1,
        },
        spaceBetween: 15,
        autoplay: true,
        slidesPerGroup: 1,
    });
}

let resizeTimeout;

function handleResize() {
    if (!resizeTimeout) {
        resizeTimeout = requestAnimationFrame(function () {
            resizeTimeout = null;
            sliders();
        });
    }
}

sliders();

window.addEventListener('resize', handleResize);