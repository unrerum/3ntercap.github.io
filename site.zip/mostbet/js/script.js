const swiperFirst = new Swiper(".swiper", {
    speed: 1000,
    autoplay: {
        delay: 5000,
    },
});
