const swiperFirst = new Swiper(".swiper", {
    speed: 400,
    spaceBetween: 100,
    autoplay: true,
    pagination: {
        el: ".swiper-pagination",
    },
});

if (window.innerWidth <= 768) {
    const swiperSecond = new Swiper(".mySwiper", {
        speed: 400,
        autoplay: {
          delay: 1000,
        },
        spaceBetween: 100,
    });
}
