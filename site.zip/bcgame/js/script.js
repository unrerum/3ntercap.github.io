const swiperFirst = new Swiper(".swiper", {
    speed: 1000,
    delay: 1000,
    slidesPerView: 3,
    spaceBetween: 20,
    slidesPerGroup: 3,
    autoplay: true,
    pagination: {
        el: ".swiper-pagination",
    },
});

const swiperSecond = new Swiper(".secondSwiper", {
    speed: 1000,
    delay: 1500,
    spaceBetween: 20,
    slidesPerGroup: 3,
    autoplay: true,
});
